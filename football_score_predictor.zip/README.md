# Football Score Predictor Web App

**An AI-powered football score prediction web app built with Streamlit, featuring Poisson regression and XGBoost models to forecast match outcomes and visualize score probabilities.**

This project is a **Streamlit web app** that predicts football match scores using **Poisson Regression** and **XGBoost**. It provides expected goals, most likely scorelines, and visual analytics.

---

## 🚀 Features
- Upload your own match dataset (CSV with `date`, `home_team`, `away_team`, `home_goals`, `away_goals`).
- Train models (Poisson or XGBoost) on historical match data.
- Predict future fixtures with expected goals.
- Probability matrix of scorelines (0–6 goals).
- Top 3 most likely outcomes.

---

## 📂 Project Structure
```
football_score_predictor/
│
├── football_score_predictor_app.py   # Main Streamlit app
├── requirements.txt                  # Dependencies
├── README.md                         # Documentation
└── demo_matches.csv                  # Sample dataset
```

---

## 🛠 Installation
1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/football_score_predictor.git
   cd football_score_predictor
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run the app:
   ```bash
   streamlit run football_score_predictor_app.py
   ```

---

## ☁️ Deployment on Streamlit Cloud
1. Push your project to **GitHub**.
2. Go to [Streamlit Cloud](https://share.streamlit.io/).
3. Connect your GitHub repo.
4. Set the **main file path** to `football_score_predictor_app.py`.
5. Deploy 🚀.

---

## 📊 Example Data Format
```csv
date,home_team,away_team,home_goals,away_goals
2023-01-01,Team A,Team B,2,1
2023-01-05,Team C,Team D,0,0
2023-01-10,Team B,Team C,1,3
```

### 📑 Demo Dataset (`demo_matches.csv`)
```csv
date,home_team,away_team,home_goals,away_goals
2023-02-01,Team A,Team C,1,1
2023-02-04,Team B,Team D,2,0
2023-02-07,Team C,Team A,0,2
2023-02-10,Team D,Team B,1,3
2023-02-15,Team A,Team D,2,2
2023-02-18,Team C,Team B,3,1
2023-02-22,Team B,Team A,0,1
2023-02-25,Team D,Team C,1,0
```

---

## 📌 Requirements
See `requirements.txt`:
```
streamlit
pandas
numpy
scikit-learn
xgboost
matplotlib
joblib
```

---

## 👤 Author
- Built with ❤️ using **Python** and **Streamlit**.
